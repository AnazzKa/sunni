$(document).ready(function () {
    var baseurl = $('#base_url').val();
    //jQuery("#po_form").validate();
    $('.sel_vendor').change(function () {
        var cur = $(this);
        vendor_id = cur.val();
        $.get(baseurl+'admin/purchase/get_vendor/'+vendor_id, function (data) {
            if(data.status){
                var data = data.data.result;
                var name = data.name;
                var phone = data.mobile;
                var addrs = data.address;
                var vendor = name+'<br/>'+phone+'<br/>'+addrs;
                $('#get_address').html(vendor);
            }else{

            }
        },'json');
    });

    $('#submit_form').click(function(e){
        e.preventDefault();
        var po_id =$('#po_id').val();
        var data = $('#po_form').serializeArray();
        var st =  $('#po_form').validate();
        console.log(st);
        st = st.toShow;

        if(st.length <= 0){
            $.post(baseurl+'admin/purchase/update_Purchaseorder/'+po_id, data, function(data){
                if(data.status)
                {
                    $.toast('Purchase order Updated successfully', {'width': 500,'duration': 1500});
                    setTimeout(function(){
                     //   window.location = baseurl+'admin/purchase';
                    }, 1000);
                }else{
                    $.toast(data.reason, {'width': 500,'duration': 1500});
                }
            },'json');
        }
    });


});
$(document).on('click', '.btn_add', function (e) {
    e.preventDefault();
    add_new_row();
});
$(document).on('click', '.btn_remov', function (e) {
    e.preventDefault();
    $(this).parent().parent().remove();
});
$(document).on('change', '.items', function(){
    var baseurl = $('#base_url').val();
    var cur = $(this);
    item_id = cur.val();
    $('.body_blur').show();
    $.get(baseurl+'admin/purchase/getstockData/'+item_id, function (data)
    {
        $('.body_blur').hide();
        if(data.status)
        {
            var data = data.data;
            var qty = data.stock;
            var price = data.price;
            var selling_price = data.selling_price;
            var mrp = data.mrp;
            var item_packing = data.item_packing;
            var sample_packing = data.sample_packing;

            var sample_price = data.sample_price;
            var sample_qty = data.sam_qty;
            cur.parent().parent().parent().find('.buy_price').val(price);
            cur.parent().parent().parent().find('.selling_price').val(selling_price);
            cur.parent().parent().parent().find('.mrp').val(mrp);
            cur.parent().parent().parent().find('.itm_pack').val(item_packing);
            cur.parent().parent().parent().find('.sample_pack').val(sample_packing);
            cur.parent().parent().parent().find('.stck_lbl').text(':In Hand: ' + qty);
            cur.parent().parent().parent().find('.sample_price').val(sample_price);
            cur.parent().parent().parent().find('.samplestck_lbl').text(':In Hand: ' + sample_qty);
        }else{

        }
    },'json');
});
function  add_new_row() {
    var prodcuts = $('#item').html();
    var warehouse = $('#warehouse').html();
    var div = '';
    div += '<div class="col-md-12 col-sm-12 col-xs-12 form-group">' +
        '<div class="col-md-2 col-sm-6 col-xs-12 form-group">' +
        '<label class="">&nbsp;</label>' +
        '<select placeholder="items" name="items[]" class="form-control selectBox items">' + prodcuts + '</select>' +
        '</div>' +
        '<div class="col-md-1 col-sm-6 col-xs-12 form-group">' +
        '<label class="stck_lbl">&nbsp;</label>' +
        '<input type="number" name="qty[]" placeholder="Qty" min="1" class="form-control qty">' +
        '</div>' +
        ' <div class="col-md-1 col-sm-6 col-xs-12 form-group">' +
        '<label class="">&nbsp;</label>' +
        '<input type="number" name="mrp[]" data-rule-required="true" placeholder="MRP" class="form-control mrp">'+
        '</div>'+
        '<div class="col-md-1 col-sm-6 col-xs-12 form-group">' +
        '<label class="">&nbsp;</label>' +
        '<input type="number" name="buy_price[]" placeholder="Price" class="form-control buy_price">' +
        '</div>' +
        '<div class="col-md-1 col-sm-6 col-xs-12 form-group">'+
        '<label>&nbsp;</label>'+
        '<select class="form-control selectBox" data-rule-required="true" name="warehouse[]">'+warehouse+'</select>'+
        '</div>'+
        '<div class="col-md-1 col-sm-6 col-xs-12 form-group">' +
        '<label class="samplestck_lbl">&nbsp;</label>' +
        '<input type="number" name="sample_qty[]" min="0" data-rule-required="true" placeholder="Sam.Qty" class="form-control sample_qty">' +
        '</div>' +
        '<div class="col-md-1 col-sm-6 col-xs-12 form-group">' +
        '<label class="">&nbsp;</label>' +
        '<input type="number" name="sample_price[]" data-rule-required="true" placeholder="Sam. Price" class="form-control sample_price">' +
        '</div>' +
        '<div class="col-md-1 col-sm-6 col-xs-12 form-group">'+
        '<label>&nbsp;</label>'+
        '<select class="form-control selectBox" data-rule-required="true" name="sample_warehouse[]">'+warehouse+'</select>'+
        '</div>'+
        '<div class="col-md-2 col-sm-6 col-xs-12 form-group">' +
        '<label class="">&nbsp;</label>' +
        '<input type="text" name="remarks[]" placeholder="Remarks" class="form-control remarks">' +
        '</div>'+
        '<div class="col-md-1 col-sm-6 col-xs-12 form-group">' +
        '<label class="">&nbsp;</label><br>' +
        '<a href="" type="button" class="btn btn-primary fllft btn_add"><i class="fa fa-plus" aria-hidden="true"></i></a>' +
        '<a href="" type="button" class="btn btn-primary fllft btn_remov"><i class="fa fa-trash" aria-hidden="true"></i></a>' +
        '</div>' +
        '</div>';
    $('#appendnewrow').append(div);

    $('.selectBox').SumoSelect({okCancelInMulti:true, selectAll:true, search:true});
}
function get_items_data()
{

    //Bom collection
    var purchase_items = {"item_ids":[],"qtys":[],"prices":[],"remarks":[]};

    //loop through tr elm

    $(".purchase_row").each(function(){

        var item_id = $(this).find(".items").val();
        var qty = $(this).find(".qty").val();
        var price = $(this).find(".buy_price").val();
        var remark = $(this).find(".remarks").val();
        purchase_items.item_ids.push(item_id);

        purchase_items.qtys.push(qty);

        purchase_items.prices.push(price);

        purchase_items.remarks.push(remark);

    });

    return purchase_items;
}